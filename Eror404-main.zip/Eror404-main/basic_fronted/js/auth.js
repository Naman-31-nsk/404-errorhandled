const EMP_URL = "http://localhost:5000/api";
async function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const role = document.getElementById("role").value;
  
  try {
    // Firebase login
    const cred = await auth.signInWithEmailAndPassword(email, password);
    const token = await cred.user.getIdToken();
    await console.log(token.split(".").length);
    
    // Backend login
    const res = await fetch(`${EMP_URL}/auth/login`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ intendedRole: role }),
    });
    
    const data = await res.json();
    
    if (!res.ok) {
      document.getElementById("msg").innerText = data.message;
      return;
    }
    
    localStorage.setItem("token", token);
    localStorage.setItem("role", data.role);
    
    if (data.role === "WORKER") {
      window.location.href = "worker.html";
    } else {
      window.location.href = "employer.html";
    }
    
  } catch (err) {
    document.getElementById("msg").innerText = err.message;
  }
}

function logout() {
  // Clear app session
  localStorage.removeItem("token");
  localStorage.removeItem("role");

  // Optional: Firebase sign out (safe even if not used)
  if (window.firebase && firebase.auth) {
    firebase.auth().signOut().catch(() => {});
  }

  // Redirect to login page
  window.location.href = "index.html";
}
