const BASE_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");

// ---------- AUTH GUARD ----------
if (!token || role !== "EMPLOYER") {
  window.location.href = "index.html";
}

// ---------- DOM READY ----------
document.addEventListener("DOMContentLoaded", () => {
  // Employer profile VIEW page
  if (document.getElementById("profileView")) {
    loadEmployerProfile();
  }

  // Employer profile EDIT page
  if (document.getElementById("profileEdit")) {
    loadEmployerProfileForEdit();
  }
});

// ---------- SAFE FIELD SETTER ----------
function setField(id, value) {
  const el = document.getElementById(id);
  console.log(el)
  if (!el) return;

  if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
    el.value = value ?? "";
  } else {
    el.innerText = value ?? "";
  }
}

// ---------- LOAD PROFILE (VIEW) ----------
async function loadEmployerProfile() {
  try {
    clearEmployerFields();
    console.log("in load profile emp")
    const res = await fetch(`http://localhost:5000/api/employer/profile`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.status === 404) {
      console.log("err hit")
      window.location.href = "employer-edit.html";
      return;
    }

    const w = await res.json();
    console.log("EMPLOYER VIEW DATA:", w.data);

    setField("workCity", w.data.workCity);
    setField("workType", w.data.workType);

  } catch (err) {
    console.error(err);
  }
}

// ---------- LOAD PROFILE (EDIT) ----------
async function loadEmployerProfileForEdit() {
  try {
    const res = await fetch(`${BASE_URL}/employer/profile`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) return;

    const w = await res.json();
    console.log("EMPLOYER EDIT DATA:", w.data);

    setField("workCity", w.data.workCity);
    setField("workType", w.data.workType);

  } catch (err) {
    console.error(err);
  }
}

// ---------- SAVE PROFILE ----------
async function saveProfile(event) {
  event.preventDefault();

  const body = {
    workCity: document.getElementById("workCity")?.value.trim(),
    workType: document.getElementById("workType")?.value.trim(),
  };

  if (!body.workCity || !body.workType) {
    document.getElementById("msg").innerText = "All fields are required";
    return;
  }

  try {
    const res = await fetch(`http://localhost:5000/api/employer/profile`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });
    console.log(res.json());

    window.location.href = "employer.html";
  } catch (err) {
    console.error(err);
  }
}

// ---------- SEARCH WORKER ----------
async function searchWorker() {
  const id = document.getElementById("searchId")?.value.trim();
  const box = document.getElementById("searchResult");

  if (!id) return;

  box.style.display = "block";
  box.innerHTML = "Searching...";

  try {
    const res = await fetch(`${BASE_URL}/employer/search/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      box.innerHTML = "<p>Worker not found</p>";
      return;
    }

    const w = await res.json();
    console.log("SEARCH RESULT:", w);

    box.innerHTML = await `
      <p><b>Name:</b> ${w.data.name}</p>
      <p><b>Origin State:</b> ${w.data.originState}</p>
      <p><b>Current City:</b> ${w.data.currentCity}</p>
      <p><b>Work Type:</b> ${w.data.workType}</p>
      <p><b>Worker ID:</b> ${w.data.workerId}</p>
      <p><b>Verified:</b> ${w.data.verified ? "Yes" : "No"}</p>
    `;
  } catch (err) {
    box.innerHTML = "<p>Error searching worker</p>";
    console.error(err);
  }
}

// ---------- CLEAR VIEW FIELDS ----------
function clearEmployerFields() {
  ["workCity", "workType"].forEach(id => {
    console.log("in random f")
    const el = document.getElementById(id);
    if (el) el.innerText = "";
  });
}

// ---------- NAV ----------
function goToEdit() {
  window.location.href = "employer-edit.html";
}
