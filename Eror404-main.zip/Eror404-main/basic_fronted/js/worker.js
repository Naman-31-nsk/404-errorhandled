const STRT_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");

if (!token || role !== "WORKER") {
  window.location.href = "index.html";
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("workerId")) {
    loadProfile();
  }

  if (document.getElementById("domicile")) {
    goToEdit();
  }
});
function setField(id, value) {
  const el = document.getElementById(id);
  console.log(`setField called: id=${id}, value=${value}, el=${el ? 'found' : 'NOT FOUND'}`);
  if (!el) return;

  if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
    el.value = value ?? "";
    console.log(`Set value for ${id}: ${el.value}`);
  } else {
    el.innerText = value ?? "";
    console.log(`Set innerText for ${id}: ${el.innerText}`);
  }
}

// -------- PROFILE VIEW --------
async function loadProfile() {
  console.log("loadProfile function hit");
  try {
    const res = await fetch(`${STRT_URL}/worker/profile`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 404) {
      window.location.href = "worker-edit.html";
      return;
    }

    const w = await res.json();
    console.log("WORKER VIEW DATA:", w.data);
    
    // Add logs for each data property
    console.log("data.workerId:", w.data.workerId);
    console.log("data.name:", w.data.name);
    // ... repeat for others if needed

    setField("workerId", "Worker ID: " + w.data.workerId);
    setField("name", w.data.name);
    setField("originState", w.data.originState);
    setField("currentCity", w.data.currentCity);
    setField("workType", w.data.workType);
    setField("language", w.data.language);
    setField("age", w.data.age);

  } catch (e) {
    console.error("Error in loadProfile:", e);
  }
}

function goToEdit() {
  window.location.href = "worker-edit.html";
}

// -------- PROFILE SAVE --------
async function saveProfile(e) {
  e.preventDefault();

  const body = {
    name: document.getElementById("name").value,
    originState: document.getElementById("originState").value,
    currentCity: document.getElementById("currentCity").value,
    workType: document.getElementById("workType").value,
    age: document.getElementById("age").value,
    language: document.getElementById("language").value,
    DomicileRefNumber: document.getElementById("domicile").value,
  };

  for (let k in body) {
    if (!body[k]) {
      document.getElementById("msg").innerText = "All fields required";
      return;
    }
  }

  await fetch(`${STRT_URL}/worker/profile`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  window.location.href = "worker.html";
}

// Auto-load only on profile view page
if (window.location.pathname.includes("worker.html")) {
  loadProfile();
}
