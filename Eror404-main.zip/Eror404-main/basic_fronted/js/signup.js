const BASE_URL = "http://localhost:5000/api";

async function signup() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const role = document.getElementById("role").value;

  try {
    // 1️⃣ Create user in Firebase
    const cred = await auth.createUserWithEmailAndPassword(email, password);

    // 2️⃣ Get ID token
    const token = await cred.user.getIdToken();

    // 3️⃣ Register user in backend
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ intendedRole: role }),
    });

    const data = await res.json();

    if (!res.ok) {
      document.getElementById("msg").innerText = data.message;
      return;
    }

    // 4️⃣ Save session
    localStorage.setItem("token", token);
    localStorage.setItem("role", data.role);

    // 5️⃣ Redirect to profile creation
    if (data.role === "WORKER") {
      window.location.href = "worker.html";
    } else {
      window.location.href = "employer.html";
    }

  } catch (err) {
    document.getElementById("msg").innerText = err.message;
  }
}
