firebase.initializeApp({
  apiKey: "AIzaSyCn6aUlxnLx0HroTo2bPGW1hZVHZ-ptWdI",
  authDomain: "error-404-bbd41.firebaseapp.com",
  projectId: "error-404-bbd41",
});

const auth = firebase.auth();
module.exports = auth;