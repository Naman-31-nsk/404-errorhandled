console.log("🔥 BACKEND BOOTED FROM", __filename);

const express = require('express');
const cors = require("cors");

const ServerConfig = require("./config/server-config");

const app = express();
const apiRoutes = require('./routes');

app.use(cors({
  origin: "*"
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api',apiRoutes)
app.get('/',(req,res)=>{
    res.json({mssg:"working fine"});
})

app.listen(ServerConfig.Port, async () => {
  console.log("server started succcessfully on port",ServerConfig.Port)
});

