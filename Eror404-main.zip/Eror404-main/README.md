> After downloading this file create an .env file to store port in it " PORT = 5000 "
> go to cmd and run " npm install "
> put the provided database(firebase key) in the main folder(backend folder)

> after running the server trough src/index.js, you can go to fronted folder named "basic_frontend" (can change the name)...
> then in frontend run the front.html to get the first page of the Site
